Before running the system:
1. Enter 'pip3 install xlsxwriter' into the terminal
This is to install the 3rd party module xlsxwriter so that the client can write onto menu.xlsx and password protect it.

To run the system:
1. Open 3 terminals and cd into /source-files
2. Start the login server by entering 'py login/login.py'
3. Start the server by entering 'py server/server.py'
4. Login on the server by entering 'melvin' as username and 'test' as password
5. Once logged in, start the client by entering 'py client/client.py'
6. Login on the client by entering 'melvin' as username and 'test' as password